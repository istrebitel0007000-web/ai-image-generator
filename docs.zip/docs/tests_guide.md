# Tests Guide

## Introduction

Tests are a crucial part of any project. Without them, supporting or refactoring becomes much more difficult and error-prone.

## Testing Approaches

There are many types of tests: unit, integration, and end-to-end (E2E), as well as black-box and white-box testing. By combining them we strike the right balance.

## How to Write Tests

- Each test must include at least two cases — one for success and one for failure.
- Tests should be independent — no test should rely on or call another.
- External resources should be mocked to isolate the functionality under test.
- Test code should be written in a declarative style — avoid loops or constructs that make code harder to read.

## Structure

```
tests/
└── users/
    ├── fixtures/
    │   ├── test_user_list/
    │   ├── test_user_detail/
    │   └── test_user_create/
    │       ├── company.json
    │       └── token.json
    ├── test_user_list.py
    ├── test_user_detail.py
    └── test_user_create.py
```

## Example Fixture

```json
[
  {
    "model": "app.User",
    "pk": 1,
    "fields": {
      "email": "user1@gmail.com",
      "password": "password1",
      "company": 1,
      "first_name": "User 1",
      "last_name": "Kim",
      "is_superuser": true,
      "is_active": true,
      "created_at": "2024-03-23T04:48:47.402555+00",
      "updated_at": "2024-03-23T04:48:47.402555+00"
    }
  }
]
```

## Example Test

```python
from rest_framework.test import APITestCase

class TestUserCreate(APITestCase):
    fixtures = [
        "app/tests/users/fixtures/test_user_create/company.json",
        "app/tests/users/fixtures/test_user_create/token.json",
    ]

    def test_user_create(self):
        data = {
            'first_name': "Bekhzod",
            'last_name': "Tillakhanov",
            'is_active': True,
            'email': "admin@gmail.com",
            'password': "123456",
        }
        headers = {"Authorization": "Token TDgk8ATW132ZG-DYkfCw6Hhf55715SSs56DY"}
        response = self.client.post("/api/v1/users/create/", data, headers=headers)
        self.assertEqual(response.status_code, 201, response)
        self.assertIsNotNone(response.data["id"])
        user = User.objects.filter(id=response.data["id"]).get()
        self.assertEqual(user.first_name, data['first_name'])
        self.assertEqual(user.last_name, data['last_name'])
        self.assertEqual(user.company.id, 1)
        self.assertEqual(user.is_active, data['is_active'])
        self.assertEqual(user.email, data['email'])
```

## Mock

Mocks allow testing interactions with external resources outside of our control. Never use mocks to test internal features.

```python
from unittest.mock import patch, MagicMock
from rest_framework.test import APITestCase

class TestUserSignUpGoogle(APITestCase):
    fixtures = [
        "app/tests/users/fixtures/test_user_create/company.json",
        "app/tests/users/fixtures/test_user_create/token.json",
    ]

    @patch("apps.auth.services.google.requests")
    def test_user_create(self, mock_requests):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"id": 1, "username": "Bekhzod"}
        mock_requests.get.return_value = mock_response

        data = {"code": "5Tihxd2KV0VsUFE_-VD4_Sq2yAMRDNuDnMDj0cF"}
        response = self.client.post("/api/v1/auth/google/sign-up/", data)
        self.assertEqual(response.status_code, 201, response)
        self.assertIsNotNone(response.data["token"])
```
