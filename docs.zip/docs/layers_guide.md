# Layers Guide: Views & Serializers

## Views

Views should focus solely on handling HTTP requests and responses. They should avoid complex business logic, serving primarily to convert incoming request data into a specific format using serializers.

## Serializers

Serializers are responsible for validating and transforming data but should not contain business logic or database queries. Their primary purpose is to ensure that the data conforms to expected formats and rules.

## Example Implementation

```python
from rest_framework.decorators import api_view
from rest_framework import serializers
from rest_framework.response import Response
from rest_framework import status
from app.services import create_user


class CreateUserRequestSerializer(serializers.Serializer):
    first_name = serializers.CharField(required=True, max_length=255)
    last_name = serializers.CharField(required=True, max_length=255)
    is_active = serializers.BooleanField(required=True)
    email = serializers.EmailField(required=True)
    password = serializers.CharField(required=True, max_length=128)


class CreateUserResponseSerializer(serializers.Serializer):
    id = serializers.IntegerField()


@api_view(["POST"])
def create_user_handler(request):
    request_serializer = CreateUserRequestSerializer(data=request.data)
    request_serializer.is_valid(raise_exception=True)
    user = create_user(request.user, request_serializer.validated_data)
    response_serializer = CreateUserResponseSerializer({'id': user.id})
    return Response(status=status.HTTP_201_CREATED, data=response_serializer.data)
```

## Key Points

- **Views**: Handle HTTP requests and responses only — keep logic minimal and clean.
- **Serializers**: Focused on simple data validation and transformation only.
- **Services**: All business logic lives here, called from the view.
- Clear separation between views and serializers keeps the application modular and maintainable.
