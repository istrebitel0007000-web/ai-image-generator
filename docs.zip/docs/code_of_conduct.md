# Code of Conduct for TMS mono

Language: python 3.9

## 1. URL Naming Conventions

- 1.1 Names used in APIs should be in correct American English
- 1.2 Use intuitive, familiar terminology (delete preferred over erase, clear, destroy)
- 1.3 Use the same name or term for the same concept across APIs
- 1.4 Use plural to indicate a collection type: `/api/v1/customers/`
- 1.5 Use hyphens (-) to improve readability: `/api/v1/orders/{id}/get-tracking/`
- 1.6 Use CRUD function names in URIs:
  - GET `/api/v1/orders/{id}/detail/`
  - GET `/api/v1/orders/list/`
  - POST `/api/v1/orders/create/`
  - PUT `/api/v1/orders/{id}/update/`
  - PATCH `/api/v1/orders/{id}/partial-update/`
- 1.7 Provide unique URI for a resource when performing an action on it:
  - Good: `/api/v1/orders/{orderId}/trips/{tripId}/add-stop/`

## 2. App Structure

```
order/
├── __init__.py
├── migrations/
├── models/
├── views/
├── services/
├── admin.py
├── apps.py
└── urls.py
```

### 2.1 Serializers

- 2.1.1 Use VerbNoun naming form. Compose with view class name + Request/Response:
  ```python
  class CreateOrderRequestSerializer(Serializer): pass
  class CreateOrderResponseSerializer(Serializer): pass
  class CreateOrderView(APIView): pass
  ```

- 2.1.2 Use `apps.core.serializer.Serializer` as base class. Never use ModelSerializer:
  ```python
  from apps.core.serializer import Serializer
  class CreateOrderRequestSerializer(Serializer): pass
  ```

- 2.1.3 Serializers should be in their simplest form — no business logic, only basic field validations.

- 2.1.4 Provide default values for non-required fields (except PATCH APIs):
  ```python
  city = serializers.CharField(required=False, default=None)
  discount = serializers.DecimalField(required=False, default=0)
  ```

- 2.1.5 Define serializers in their corresponding view files — no separate serializer files.

### 2.2 Services

- 2.2.1 Structure service files in immediate `services/` folder, avoid nesting.
- 2.2.2 Follow Single Responsibility Principle — each service responsible for only one action.
- 2.2.3 Use `verb_noun` naming convention: `create_order.py`, `update_order.py`
- 2.2.4 Use additional protected functions (prefix `_`) inside a service when required:
  ```python
  def create_order(*args, **kwargs):
      _validate()
      _notify_driver()

  def _validate(*args, **kwargs): pass
  def _notify_driver(): pass
  ```

### 2.3 Views

- 2.3.1 Use VerbNoun form in naming Views: `CreateOrderView`, `UpdateOrderView`
- 2.3.2 Use `verb_noun` form in naming view files: `create_order.py`, `update_order.py`
- 2.3.3 Structure view files in immediate `views/` folder, avoid nesting.
- 2.3.4 Use CBV (Class-Based Views) only. Avoid ViewSets and function views.
- 2.3.5 Keep views simple — only handle HTTP requests/responses, no business logic:
  ```python
  class UpdateOrderView(APIView):
      def put(self, request, pk):
          serializer = UpdateOrderRequestSerializer(data=request.data)
          serializer.is_valid(raise_exception=True)
          order = update_order(pk, serializer.data)
          serializer = UpdateOrderResponseSerializer(order)
          return Response(status=status.HTTP_200_OK, data=serializer.data)
  ```

### 2.4 Models

- 2.4.1 Define foreign key relationships in quotes:
  ```python
  order = models.ForeignKey("Order", on_delete=models.CASCADE)
  ```

- 2.4.2 Avoid placing any logic in model definition — all logic in service layer.

- 2.4.3 Define Enums inside model class using singular naming:
  ```python
  class Order(BaseModel):
      class Status(models.TextChoices):
          BOOKED = "booked", "Booked"
          IN_TRANSIT = "in_transit", "In Transit"
      status = models.CharField(choices=Status.choices, default=Status.BOOKED)
  ```

- 2.4.4 Use JSONField for grouped related fields:
  ```python
  class Customer(BaseModel):
      class BillingAddress(TypedDict):
          type: str
          email: str
          city: str
      billing_address: BillingAddress = models.JSONField()
  ```

## 3. Testing

### 3.1 Structure

```
tests/
└── order/
    ├── fixtures/
    │   ├── test_create_order/
    │   └── test_update_order/
    ├── __init__.py
    ├── test_create_order.py
    └── test_update_order.py
```

- 3.1.2 Avoid nesting unless it makes sense.
- 3.1.3 Use `test_verb_noun` convention in naming test files: `test_create_order.py`

### 3.2 Tests

- 3.2.1 One feature per test file. Never mix different endpoint tests in one file.
- 3.2.2 Use separate fixtures for separate test files, named same as the test file.
- 3.2.3 Avoid overloading tests with unnecessary fixtures.
- 3.2.4 Use generic name + docstring in test functions:
  ```python
  def test_cancel_order_case_1(self):
      """
      Case: Attempt to cancel booked order
      Expected: Success
      """
      pass
  ```

- 3.2.5 Use model name as fixture model: `"model": "order.OrderStop"`
- 3.2.6 Avoid mixing different models into single fixture file.
- 3.2.7 Use literal values in assert statements:
  ```python
  self.assertEqual(order.status, Order.BOOKED)
  self.assertEqual(order.note, "Lorem ipsum dolor sit amet")
  ```

- 3.2.8 Pass query params as argument in request:
  ```python
  query_params = {"page": 1, "page_size": 20}
  response = self.client.get("/api/v1/orders/list/", query_params)
  ```

### 3.3 Mocking

- 3.3.1 Use `mock_{mocked_function_name}` naming convention.
- 3.3.2 Never mock internal functions — only mock external calls.
- 3.3.3 Use mocking in datetime-dependent tests:
  ```python
  @mock.patch("django.utils.timezone.now")
  def test_list_weekly_orders(self, mock_now: Mock):
      mock_now.return_value = timezone.datetime(2024, 1, 5, tzinfo=timezone.utc)
  ```
